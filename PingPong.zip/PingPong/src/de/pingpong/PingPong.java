package de.pingpong;

public class PingPong {



	public static void main(String[] args) {

		

		GameFrame frame = new GameFrame();

		

	}

}